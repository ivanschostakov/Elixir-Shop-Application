<?php

use Bitrix\Main\Config\Option;
use Bitrix\Main\Context;
use Bitrix\Main\Loader;

defined('B_PROLOG_INCLUDED') || die();

$moduleId = 'elixir.reviewsync';
if (!Loader::includeModule($moduleId) || !$USER->IsAdmin()) {
    return;
}

$request = Context::getCurrent()->getRequest();
$message = null;
$error = null;

if ($request->isPost() && check_bitrix_sessid()) {
    $newSecret = trim((string)$request->getPost('shared_secret_new'));
    if ($newSecret !== '' && strlen($newSecret) < 32) {
        $error = 'Секрет должен содержать не менее 32 символов.';
    } elseif ($newSecret !== '') {
        Option::set($moduleId, 'shared_secret', $newSecret);
        $message = 'Секрет синхронизации сохранён.';
    } else {
        $message = 'Настройки не изменены.';
    }
}

$isConfigured = strlen(trim(Option::get($moduleId, 'shared_secret', ''))) >= 32;
?>
<?php if ($message !== null): ?>
    <div class="adm-info-message-wrap"><div class="adm-info-message"><?= htmlspecialcharsbx($message) ?></div></div>
<?php endif; ?>
<?php if ($error !== null): ?>
    <div class="adm-info-message-wrap"><div class="adm-info-message adm-info-message-red"><?= htmlspecialcharsbx($error) ?></div></div>
<?php endif; ?>

<form method="post" action="<?= $APPLICATION->GetCurPage() ?>?mid=<?= urlencode($moduleId) ?>&lang=<?= LANGUAGE_ID ?>">
    <?= bitrix_sessid_post() ?>
    <table class="adm-detail-content-table edit-table">
        <tr class="heading"><td colspan="2">Двусторонняя синхронизация отзывов</td></tr>
        <tr>
            <td width="40%">Состояние:</td>
            <td><?= $isConfigured ? 'Секрет настроен' : 'Секрет не настроен' ?></td>
        </tr>
        <tr>
            <td>Новый shared secret:</td>
            <td><input type="password" name="shared_secret_new" size="60" autocomplete="new-password" placeholder="Пусто — оставить текущий"></td>
        </tr>
    </table>
    <input type="submit" class="adm-btn-save" value="Сохранить">
</form>
